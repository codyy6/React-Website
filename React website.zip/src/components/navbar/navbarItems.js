export const Items = [
    {
        title: 'Home',
        url:'/React-Website'
    },
    {
        title: 'About',
        url:'/about'
    },
    {
        title: 'CV/Resume',
        url:'/cv'
    },
    {
        title: 'Transcripts',
        url:'/transcripts'
    },
    {
        title: 'Working Experiences',
        url:'/workingexperiences'
    }
    ,{
        title: 'Skills',
        url:'/skills'
    }
]