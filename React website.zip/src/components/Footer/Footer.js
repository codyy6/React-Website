import React from 'react'
import './Footer.css'
const Footer = () => {
    return (
        <>
        <div className='footer'>
            <p>Cody Liew Chern Jin</p>
            <p>codyyliew@gmail.com</p>
            <p>Copyright 2022</p>
        </div>
        </>
    )
}

export default Footer