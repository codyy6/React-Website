import React, {useState} from 'react'
import "./Cv.css"
const Cv = () => {
    document.title="Cody Liew's CV"
  return (
    <div className='cv'>
      <iframe src="https://drive.google.com/file/d/1zj_s5KYHhbSQJzsx5j7u21BqzmEc28Ti/preview" allow="autoplay"/>
    </div>
  )
}

export default Cv