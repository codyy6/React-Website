const details =[{
    title: "IT",
    skills:[    
        "Python",
        "Java",
        "HTML",
        "CSS",
        "Javascript",
        "Node JS",
        "React",
        "Data Cleaning",
        "Data Analysing",
        "Networking",
        "Software Testing",
        "MS Office",
        "Machine Learning (Theory)",
        "Blockchain Technology (Theory)"
    ]
},{
    title: "Non IT",
    skills:[
        "Communication Skills",
        "Interpersonal Skills",
        "Collaboration",
        "Flexibility",
        "Time Management",
        "Strategic Planning",
        "Leadership"
    ]
},{
    title: "Language",
    skills:[
        "Chinese",
        "English",
        "Malay"
    ]
}
]
export default details;