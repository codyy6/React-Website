import React from 'react'
import "./Transcripts.css"
const transcripts = () => {
    document.title="Cody Liew's Transcript"
  return (
    <div className='pdf'>
      <iframe src="https://drive.google.com/file/d/1A6o1dtGeyXqEwdKVexpokRiIP13fKhOZ/preview" allow="autoplay" />  
    </div>
)}

export default transcripts