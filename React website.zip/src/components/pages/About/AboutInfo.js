const details=[{
    //Uni data
    img:'https://drive.google.com/uc?export=view&id=1WJChCR8KQNBMjBYgBH2DWy5nTyLwLgQh',
    alt:'Asia Pacific University',
    h2:"Asia Pacific University of Technology & Innovation, Bukit Jalil",
    details:[<br></br>,
    <h3>Asia Pacific Analytic Club (APAC) - member</h3>,
    <li>Joined different events organised by the club</li>,
    <li>Participated in industrial visit held within the club</li>,
    <br></br>,
    <h3>Microsoft Learning Student Accelerator Program (MLSA) - Participant</h3>,
    <li>Made prototype on a simple attendance system</li>,
    <li>Learnt different pioneer technology developed by Microsoft</li>,
    <li>Discovered new technology</li>
]
},{
    //High School Data
    img:"https://drive.google.com/uc?export=view&id=1gjk6f4bLaxYRFGXZTozh2_5x4CP3NCp1",
    alt:'Catholic High School',
    h2:"Catholic High School, Petaling Jaya",
    details:[<br></br>,
    <h3><u>Form 5</u></h3>,
    <h4>Quarter Master - Vice President 1</h4>,
    <li>Led the group in MSSS Track & Field Duty</li>,
    <li>Supervise over juniors in handling MSSD Track & Field Duty</li>,
    <li>Organise all of the Track & Field events in school</li>,
    <li>Ensuring the discipline of the club members</li>,
    <br></br>,
    <h4>Handball Club - Stock Manager</h4>,
    <li>Making sure the balls are kept safe</li>,
    <li>Ensure the quality of the balls before training</li>,
    <br></br>,
    <h3><u>Form 4</u></h3>,
    <h4>Quarter Master - Vice President 2</h4>,
    <li>Led the group in MSSD Track & Fields Duty</li>,
    <li>Help the MSSS Aquatic Organisers in doing tasks</li>,
    <li>Organising the Track & Fields Events in school</li>,
    <br></br>,
    <h4>Young Enterprise - Purchasing Manager</h4>,
    <li>Ensuring the quality of the raw materials</li>,
    <li>Checking the raw materials' list to be purchased</li>,
    <li>Help selling final product during the sales event</li>,
    <br></br>,
    <h3><u>Form 3</u></h3>,
    <h4>Assistant Stock Manager 2</h4>,
    <li>Help tally all of the stock in the checklist</li>,
    <li>Ensuring the check stock list done by juniors are accurate</li>,
    <li>Make sure all of the stock equipment are kept safely</li>,
    <li>ensure the cleanliness and condition of stock rooms</li>

]   
}]

export default details;